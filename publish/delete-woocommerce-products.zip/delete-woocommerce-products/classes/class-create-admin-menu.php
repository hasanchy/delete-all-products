<?php
/**
 * This file will create admin menu page.
 */

class DWP_Create_Admin_Page {

    public function __construct() {
        add_action( 'admin_menu', [ $this, 'create_admin_menu' ] );
    }

    public function create_admin_menu() {
        $capability = 'manage_options';
        $slug = 'dwp-settings';

        $hook = add_menu_page(
            __( 'DWP', 'delete-woocommerce-products' ),
            __( 'DWP', 'delete-woocommerce-products' ),
            $capability,
            $slug,
            [ $this, 'menu_page_template' ],
            'dashicons-trash'
        );
		add_action( 'load-' . $hook, [$this, 'delete_load_scripts'] );
    }

	function delete_load_scripts() {
		wp_enqueue_style( 'jobplace-style', DWP_URL . 'build/index.css' );
		wp_enqueue_script( 'delete-woocommerce-products', DWP_URL . 'build/index.js', [ 'jquery', 'wp-element' ], wp_rand(), true );
		wp_localize_script( 'delete-woocommerce-products', 'appLocalizer', [
			'apiUrl' => home_url( '/wp-json' ),
			'nonce' => wp_create_nonce( 'wp_rest' ),
		] );
	}

    public function menu_page_template() {
        echo '<div class="wrap"><div id="dwp-admin-app"></div></div>';
    }

}
new DWP_Create_Admin_Page();