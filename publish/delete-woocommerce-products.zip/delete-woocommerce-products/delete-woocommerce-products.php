<?php
/**
 * Plugin Name: DWP - Delete Woocommerce Products
 * Author: Hasan Chowdhury
 * Author URI: https://themesocean.com
 * Version: 1.0.0
 * Description: This plugin allows you to delete all woocommerce products from the database.
 * Text-Domain: delete-woocommerce-products
 */

if( ! defined( 'ABSPATH' ) ) : exit(); endif; // No direct access allowed.

/**
* Define Plugins Contants
*/
define ( 'DWP_PATH', trailingslashit( plugin_dir_path( __FILE__ ) ) );
define ( 'DWP_URL', trailingslashit( plugins_url( '/', __FILE__ ) ) );

/**
 * Loading Necessary Scripts
 */
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'delete_settings_link');
function delete_settings_link($links)
{
	if (is_array($links)) {
		$sab1 = sprintf('<a href="%s"><b>%s</b></a>', admin_url('admin.php?page=dwp-settings'), __('Donate', 'dwp-settings'));
		$sab2 = sprintf('<a href="%s">%s</a>', admin_url('admin.php?page=dwp-settings'), __('Delete Products', 'dwp-settings'));
		array_unshift($links, $sab1);
		array_unshift($links, $sab2);
	}
	return $links;
}

require_once DWP_PATH . 'classes/class-create-admin-menu.php';
require_once DWP_PATH . 'classes/class-create-settings-routes.php';