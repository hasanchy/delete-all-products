<?php
// Cachebusters generated on 2023-09-29 06:02:36
return [
	'src/public/dist/admin.css'=> wp_rand(),
	'src/public/dist/admin.css.map'=> wp_rand(),
	'src/public/dist/admin.lite.js'=> wp_rand(),
	'src/public/dist/admin.lite.js.map'=> wp_rand(),
	// 'src/public/dist/admin.css'=> '83514cd114a6387d5c25fe448b20035a0',
	// 'src/public/dist/admin.css.map'=> 'bb196b440f080edef0d5bc950f5b2a5d',
	// 'src/public/dist/admin.lite.js'=> '34db17a06ae27af58e69915d18ba62b60',
	// 'src/public/dist/admin.lite.js.map'=> '730f69f1098b2d78774128c0a6323802',
];
