import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Settings = () => {

	const [total, setTotalProducts] = useState(0);
	const [trash, setTrashProducts] = useState(0);
	const [activeTab, setActiveTab] = useState('all');
	const [mover, setMover] = useState('Move To Trash');
	const [deleter, setDeleter] = useState('Delete Permanently');
	const [restorer, setRestorer] = useState('Restore Trash');
	const [message, setMessage] = useState('');

	const deleteURL = `${appLocalizer.apiUrl}/dwp/v1/delete`;
	const url = `${appLocalizer.apiUrl}/dwp/v1/settings`;

	useEffect(() => {
		setInterval(fetchData, 5000);
	}, [])

	const handleMoveToTrash = (e) => {
		e.preventDefault();
		setMover('Moving...');
		axios.post(url, { action: 'move-to-trash' }, {
			headers: {
				'content-type': 'application/json',
				'X-WP-NONCE': appLocalizer.nonce
			}
		})
			.then((res) => {
				setTotalProducts(res.data.total);
				setTrashProducts(res.data.trash);
				setMover('Move To Trash');
				setMessage('Products moved to trash successfully.');
			})
	}

	const handleRestoreTrash = (e) => {
		e.preventDefault();
		setRestorer('Restoring...');
		axios.post(url, { action: 'restore-trash' }, {
			headers: {
				'content-type': 'application/json',
				'X-WP-NONCE': appLocalizer.nonce
			}
		}).then((res) => {
			// fetchData();
			setTotalProducts(res.data.total);
			setTrashProducts(res.data.trash);
			setRestorer('Restore Trash');
			setMessage('Products restored successfully.');
		})
	}

	const handlePermanentDelete = (e) => {
		e.preventDefault();
		setDeleter('Deleting...');
		axios.post(deleteURL, { action: 'permanent-delete' }, {
			headers: {
				'content-type': 'application/json',
				'X-WP-NONCE': appLocalizer.nonce
			}
		})
			.then((res) => {
				// fetchData();
				setTotalProducts(res.data.total);
				setTrashProducts(res.data.trash);
				setDeleter('Delete Permanently');
				setMessage('Products deleted permanently successfully.');
			});
	}

	const handleTrashDelete = (e) => {
		e.preventDefault();
		setDeleter('Deleting...');
		axios.post(url, { action: 'trash-delete' }, {
			headers: {
				'content-type': 'application/json',
				'X-WP-NONCE': appLocalizer.nonce
			}
		})
			.then((res) => {
				// fetchData();
				setTotalProducts(res.data.total);
				setTrashProducts(res.data.trash);
				setDeleter('Delete Permanently');
				setMessage('Products deleted successfully.');
			})
	}

	const fetchData = () => {
		axios.get(url).then((res) => {
			setTotalProducts(res.data.total);
			setTrashProducts(res.data.trash);
		})
	}

	const renderAllTabContent = () => {
		if (!total) {
			return <p>No products found</p>;
		}
		return <div>
			<p>
				<button className="button button-primary" onClick={(e) => handlePermanentDelete(e)}>{deleter}</button>
				<button className="button button-primary" style={{ marginLeft: '10px' }} onClick={(e) => handleMoveToTrash(e)}>{mover}</button>
			</p>
		</div>
	}

	const renderTrashTabContent = () => {
		if (!trash) {
			return <p>No products found in trash</p>;
		}
		return <div>
			<p>
				<button className="button button-primary" onClick={(e) => handleTrashDelete(e)}>{deleter}</button>
				<button className="button button-primary" style={{ marginLeft: '10px' }} onClick={(e) => handleRestoreTrash(e)}>{restorer}</button>
			</p>
		</div>
	}

	const renderResources = () => {
		return <p>
			<a href="https://www.greengeeks.com/track/chowdhuryhms/cp-default" target="_top">
				<img border="0" src="https://ads.greengeeks.com/00040049.gif" />
			</a>
		</p>
	}

	const renderTabContent = () => {
		if (activeTab === 'all') {
			return renderAllTabContent();
		} else if (activeTab === 'trash') {
			return renderTrashTabContent();
		} else {
			return renderResources();
		}
	}

	const renderMessage = () => {
		if (message) {
			return <div id="setting-error-settings_updated" className="notice notice-success settings-error is-dismissible">
				<p><strong>{message}</strong></p>
				<button type="button" className="notice-dismiss" onClick={() => setMessage('')}>
					<span className="screen-reader-text">Dismiss this notice.</span>
				</button>
			</div>
		} else {
			return null;
		}
	}

	return (
		<React.Fragment>
			<div className="wrap">
				<h1>Delete WooCommerce Products</h1>
				{renderMessage()}
				<nav className="nav-tab-wrapper">
					<a href="#" className={activeTab === 'all' ? 'nav-tab nav-tab-active' : 'nav-tab'} onClick={() => setActiveTab('all')}>All ({total})</a>
					<a href="#" className={activeTab === 'trash' ? 'nav-tab nav-tab-active' : 'nav-tab'} onClick={() => setActiveTab('trash')}>Trash ({trash})</a>
					<a href="#" className={activeTab === 'resources' ? 'nav-tab nav-tab-active' : 'nav-tab'} onClick={() => setActiveTab('resources')}>WooCommerce Resources</a>
				</nav>
				<div className="tab-content">
					{renderTabContent()}
				</div>
			</div>
		</React.Fragment>
	)
}

export default Settings;